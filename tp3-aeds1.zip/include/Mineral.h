#ifndef MINERAL_H
#define MINERAL_H

typedef struct Mineral {

char nome[15];

} Mineral;

void inicializa_mineral(Mineral* mineral,char* nome);
char* get_nome(Mineral* mineral);
#endif